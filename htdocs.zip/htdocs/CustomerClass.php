<?php
class Customer {
    private $id;
    private $name;
    private $email;

    public function __construct($id, $name, $email) {
        $this->id = $id;
        $this->name = $name;
        $this->email = $email;
    }

    public function getName() {
        return $this->name;
    }

    public function getEmail() {
        return $this->email;
    }

    // Display available menu items
    public function viewMenu(MenuManager $menuManager) {
        $items = $menuManager->getItems();
        $menuHtml = "<h2>Menu</h2><ul>";
        foreach ($items as $item) {
            $menuHtml .= "<li>" . htmlspecialchars($item->getName()) . " - $" . htmlspecialchars($item->getPrice());
            $menuHtml .= " <input type='number' name='quantity[" . $item->getId() . "]' value='0' min='0' style='width: 50px;'>";
            $menuHtml .= " Customization: <input type='text' name='customization[" . $item->getId() . "]' placeholder='e.g., no sugar'>";
            $menuHtml .= "</li>";
        }
        $menuHtml .= "</ul>";
        return $menuHtml;
    }

    // Reserve a table
    public function reserveTable(ReservationManager $reservationManager, $tableId) {
        return $reservationManager->reserveTable($tableId);
    }

    // View available tables
    public function viewAvailableTables(ReservationManager $reservationManager) {
        $tables = $reservationManager->getTables();
        $tableHtml = "<h2>Reserve a Table</h2>";
        foreach ($tables as $table) {
            if ($table->isAvailable()) {
                $tableHtml .= "<div><input type='radio' name='tableId' value='" . $table->getId() . "'> Table " . $table->getId() . " for " . $table->getCapacity() . " people</div>";
            }
        }
        return $tableHtml;
    }
}
?>
