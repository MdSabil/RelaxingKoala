<?php
include_once 'TableClass.php';

class ReservationManager {
    private $tables;

    public function __construct() {
        $this->tables = [];
    }

    public function addTable(Table $table) {
        $this->tables[$table->getId()] = $table;
    }

    public function reserveTable($tableId) {
        if (isset($this->tables[$tableId]) && $this->tables[$tableId]->isAvailable()) {
            $this->tables[$tableId]->setAvailability(false);
            return true;
        }
        return false;
    }

    public function getTables() {
        return $this->tables;
    }

    public function findTableById($id) {
        if (isset($this->tables[$id])) {
            return $this->tables[$id];
        }
        return null;
    }
}
?>
