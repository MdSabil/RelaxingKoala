<?php
class MenuManager {
    private $items; // Array of Items objects

    public function __construct() {
        $this->items = [];
    }

    public function addItem($item) {
        $this->items[] = $item;
    }

    public function getItems() {
        return $this->items;
    }
}
?>
