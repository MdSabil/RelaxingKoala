<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Restaurant Menu and Table Reservation</title>
</head>
<body>
    <h1>Welcome to Our Restaurant</h1>

    <form method="POST">
        <div>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <button type="submit" name="viewMenu">View Menu and Reserve Table</button>
    </form>

    <?php
    include_once 'ItemClass.php';
    include_once 'MenuManagerClass.php';
    include_once 'ReservationManagerClass.php';
    include_once 'TableClass.php';
    include_once 'CustomerClass.php';

    // Initialize managers and customer
    $menuManager = new MenuManager();
    $menuManager->addItem(new Item(1, "Coffee", "Delicious hot coffee.", 2.99));
    $menuManager->addItem(new Item(2, "Tea", "Organic green tea.", 2.50));

    $reservationManager = new ReservationManager();
    $reservationManager->addTable(new Table(1, 4, true));
    $reservationManager->addTable(new Table(2, 2, true));

    $customer = new Customer(1, "John Doe", "john@example.com");

    // Handle view menu and reservation form display
    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['viewMenu'])) {
        echo "<form method='POST'>";
        echo $customer->viewMenu($menuManager);
        echo $customer->viewAvailableTables($reservationManager);
        echo "<button type='submit' name='placeOrder'>Place Order</button>";
        echo "</form>";
    } elseif ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['placeOrder'])) {
        // Handle order placement and table reservation
        echo "<h2>Order Confirmation:</h2><ul>";
        $totalCost = 0;
        foreach ($_POST['quantity'] as $id => $quantity) {
            if ($quantity > 0) {
                $item = $menuManager->findItemById($id);
                $customization = $_POST['customization'][$id] ?? 'None';
                $cost = $quantity * $item->getPrice();
                $totalCost += $cost;
                echo "<li>" . htmlspecialchars($quantity) . ' x ' . htmlspecialchars($item->getName()) . " at $" . htmlspecialchars($item->getPrice()) . " each. Total: $" . htmlspecialchars($cost) . ". Customization: " . htmlspecialchars($customization) . "</li>";
            }
        }
        if (isset($_POST['tableId'])) {
            $table = $reservationManager->findTableById($_POST['tableId']);
            if ($table && $table->isAvailable()) {
                $reservationManager->reserveTable($_POST['tableId']);
                echo "<li>Table " . htmlspecialchars($_POST['tableId']) . " reserved.</li>";
            } else {
                echo "<li>Table " . htmlspecialchars($_POST['tableId']) . " is not available.</li>";
            }
        }
        echo "</ul>";
        echo "<p>Total Cost: $" . htmlspecialchars($totalCost) . "</p>";
    }
    ?>

</body>
</html>
