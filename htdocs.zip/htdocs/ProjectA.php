<?php
require_once __DIR__ . '/vendor/autoload.php'; // Ensure you have this line to include Composer's autoload

use MongoDB\Client;
use MongoDB\Driver\ServerApi;

$uri = 'mongodb+srv:// FYPUSERS:k1iTgwyFFzGlAkeN@fyptestdb.d7zdlnq.mongodb.net/';
$apiVersion = new ServerApi(ServerApi::V1);

// Create a new client and connect to the server with API versioning
$client = new MongoDB\Client($uri, [], ['serverApi' => $apiVersion]);

try {
    // Select the database and collection
    $collection = $client->FYPDataCollection->HealthData; // Replace with your actual database and collection names

    // Fetch documents from the collection
    $documents = $collection->find();

    // Display documents in a table
    echo "<table border='1'>";
    echo "<tr><th>Heart Rate (bpm)</th><th>Oxygen Saturation (%)</th><th>Ouch Button Frequency</th><th>Last Pressed</th></tr>";
    foreach ($documents as $doc) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($doc['healthData']['heartRate']['value']) . " bpm</td>";
        echo "<td>" . htmlspecialchars($doc['healthData']['oxygenSaturation']['value']) . "%</td>";
        echo "<td>" . htmlspecialchars($doc['healthData']['ouchButton']['frequency']) . "</td>";
        echo "<td>" . htmlspecialchars($doc['healthData']['ouchButton']['lastPressed']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
