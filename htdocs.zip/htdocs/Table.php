<?php
class Table {
    private $id;
    private $capacity;
    private $isAvailable;

    public function __construct($id, $capacity, $isAvailable = true) {
        $this->id = $id;
        $this->capacity = $capacity;
        $this->isAvailable = $isAvailable;
    }

    public function getId() {
        return $this->id;
    }

    public function getCapacity() {
        return $this->capacity;
    }

    public function isAvailable() {
        return $this->isAvailable;
    }

    public function setAvailability($availability) {
        $this->isAvailable = $availability;
    }
}
?>
