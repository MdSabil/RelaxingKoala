<?php
include_once 'ItemClass.php';

class MenuManager {
    private $items = [];

    public function addItem(Item $item) {
        $this->items[] = $item;
    }

    public function getItems() {
        return $this->items;
    }

    public function findItemById($id) {
        foreach ($this->items as $item) {
            if ($item->getId() == $id) {
                return $item;
            }
        }
        return null; // Return null if no item matches
    }
}
?>
