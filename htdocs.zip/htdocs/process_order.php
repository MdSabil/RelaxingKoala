<?php
include_once 'database.php';
include_once 'MenuManagerClass.php';
include_once 'ItemClass.php';
include_once 'CustomerClass.php';
include_once 'OrderClass.php';

$database = new Database();
$db = $database->getConnection();

$menuManager = new MenuManager();
$menuManager->addItem(new Item(1, "Coffee", "Delicious hot coffee.", 2.99));
$menuManager->addItem(new Item(2, "Tea", "Organic green tea.", 2.50));

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['name'], $_POST['email'], $_POST['items'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $selectedItemIds = $_POST['items'];

    // Create a new customer
    $customer = new Customer(1, $name, $email); // Assume customer ID is 1 for simplicity

    // Customer selects items by IDs from the form
    $selectedItems = $customer->selectItems($menuManager, $selectedItemIds);

    // Customer places an order
    $order = $customer->orderItems($selectedItems);
    echo "Order placed by " . $order->getCustomer()->getName() . "<br/>";
    echo "Total Cost: $" . $order->getTotalCost() . "<br/>";
} else {
    echo "No items selected. Please go back and select items to order.";
}
?>
