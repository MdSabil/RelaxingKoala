const { MongoClient } = require('mongodb');

// Connection URL from your Atlas Admin UI
const url = 'mongodb+srv://FYPUSERS:k1iTgwyFFzGlAkeN@fyptestdb.d7zdlnq.mongodb.net/';

const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

// Database Name
const dbName = 'FYPDataCollection'; // Replace with your actual database name

async function main() {
    try {
        // Connect the client to the server
        await client.connect();
        console.log("Connected successfully to MongoDB Atlas");

        const db = client.db(dbName);

        // Example: Fetch first document from some collection
        const collection = db.collection('yourCollectionName'); // Replace with your actual collection name
        const document = await collection.findOne({});
        console.log(document);

    } finally {
        // Ensures that the client will close when you finish/error
        await client.close();
    }
}

main().catch(console.error);
