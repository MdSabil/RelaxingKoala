<?php
class ReservationManager {
    private $tables;

    public function __construct() {
        $this->tables = [];
    }

    public function addTable(Table $table) {
        $this->tables[$table->getId()] = $table;
    }

    public function reserveTable($tableId) {
        if (isset($this->tables[$tableId]) && $this->tables[$tableId]->isAvailable()) {
            $this->tables[$tableId]->setAvailability(false);
            return true;
        }
        return false;
    }

    public function getAvailableTables() {
        return array_filter($this->tables, function($table) {
            return $table->isAvailable();
        });
    }
}
?>
